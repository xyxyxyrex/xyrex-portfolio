Clea scribble logo and favicon pack

The editable charcoal and light SVG masters preserve the loose diagonal scribble from the supplied reference. The favicon uses a simplified small-size version on a beige background.

Recommended HTML (copy these files into your app public directory):
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

Includes SVG marks, PNG exports at 16/32/48/180/192/512px, and an ICO containing 16/24/32/48/64px entries.
